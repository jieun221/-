import asyncio, logging, os
from datetime import datetime, timezone
import discord
from discord.ext import commands
from core.config import TOKEN, OWNER_ID, DATABASE_PATH
from core.db import Database
from core.utils import emb

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")

EXTENSIONS = (
    "cogs.owner",
    "cogs.settings",
    "cogs.staff",
    "cogs.roles",
    "cogs.points",
    "cogs.tickets",
    "cogs.moderation",
    "cogs.security",
    "cogs.events",
    "cogs.reports",
    "cogs.backup",
    "cogs.stats",
)

class TotalAdminBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True
        intents.message_content = True
        intents.moderation = True
        super().__init__(command_prefix="!", intents=intents)
        self.db = Database(DATABASE_PATH)

    async def setup_hook(self):
        os.makedirs(os.path.dirname(DATABASE_PATH) or ".", exist_ok=True)
        await self.db.init()
        for ext in EXTENSIONS:
            await self.load_extension(ext)
        synced = await self.tree.sync()
        logging.info("동기화된 명령어: %s", len(synced))

    async def on_ready(self):
        for g in self.guilds:
            await self.db.upsert_guild(g.id, g.name)
        await self.change_presence(
            status=discord.Status.online,
            activity=discord.Game(name="/설정 | /총괄")
        )
        logging.info("READY %s (%s)", self.user, self.user.id)

    async def on_guild_join(self, guild):
        await self.db.upsert_guild(guild.id, guild.name, datetime.now(timezone.utc).isoformat())

        if guild.me and guild.me.guild_permissions.view_audit_log:
            try:
                async for entry in guild.audit_logs(limit=10, action=discord.AuditLogAction.bot_add):
                    if getattr(entry.target, "id", None) == self.user.id:
                        await self.db.add_rep(guild.id, entry.user.id, OWNER_ID)
                        break
            except Exception:
                pass

        if guild.me and guild.me.guild_permissions.manage_channels:
            try:
                ch = discord.utils.get(guild.text_channels, name="봇-로그")
                if not ch:
                    ch = await guild.create_text_channel("봇-로그", reason="총관리 봇 로그")
                await self.db.set_guild_field(guild.id, "log_channel_id", ch.id)
                await ch.send(embed=emb("✅ 총관리 봇 연결 완료","`/설정 보기`를 사용하세요."))
            except Exception:
                pass

    async def interaction_check(self, interaction):
        if interaction.user.id == OWNER_ID:
            return True

        state = await self.db.get_global("maintenance", {"enabled":False})
        if state.get("enabled"):
            await interaction.response.send_message(
                "🛠️ **현재 전체 점검 중입니다.**\n"
                f"사유: {state.get('reason','점검')}\n"
                f"종료 예정: {state.get('eta','미정')}\n"
                f"오류: {state.get('error','-')}\n"
                f"예상 복구: {state.get('recovery','미정')}\n"
                f"추가 안내: {state.get('notice','-')}",
                ephemeral=True
            )
            return False

        if interaction.guild and await self.db.is_guild_blocked(interaction.guild.id):
            await interaction.response.send_message("⛔ 이 서버는 봇 사용이 차단되었습니다.",ephemeral=True)
            return False
        return True

bot = TotalAdminBot()

@bot.tree.error
async def on_error(interaction, error):
    logging.exception("app command error", exc_info=error)
    text = f"⛔ {error}" if isinstance(error, discord.app_commands.CheckFailure) else "❌ 명령 처리 중 오류가 발생했습니다."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)
    except Exception:
        pass

async def main():
    async with bot:
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
