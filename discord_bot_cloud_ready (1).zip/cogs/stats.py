import discord, psutil
from discord import app_commands
from discord.ext import commands
from core.checks import owner_only, guild_manager_only
from core.utils import emb

class StatsCog(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name="통계",description="봇 전체 통계")
    @owner_only()
    async def total(self,interaction:discord.Interaction):
        rows=await self.bot.db.list_guilds()
        e=emb("📊 전체 통계")
        e.add_field(name="서버 수",value=str(len(self.bot.guilds)))
        e.add_field(name="총 멤버",value=f"{sum((g.member_count or 0) for g in self.bot.guilds):,}")
        e.add_field(name="차단 서버",value=str(sum(1 for r in rows if r[3])))
        e.add_field(name="메모리",value=f"{psutil.Process().memory_info().rss/1024/1024:.1f} MB")
        await interaction.response.send_message(embed=e,ephemeral=True)

    @app_commands.command(name="서버통계",description="현재 서버 통계")
    @guild_manager_only()
    async def server(self,interaction:discord.Interaction):
        gid=interaction.guild.id
        warnings=(await self.bot.db.fetchone("SELECT COUNT(*) FROM warnings WHERE guild_id=?",(gid,)))[0]
        tickets=(await self.bot.db.fetchone("SELECT COUNT(*) FROM tickets WHERE guild_id=?",(gid,)))[0]
        reports=(await self.bot.db.fetchone("SELECT COUNT(*) FROM reports WHERE guild_id=?",(gid,)))[0]
        points=(await self.bot.db.fetchone("SELECT COALESCE(SUM(amount),0) FROM points WHERE guild_id=?",(gid,)))[0]
        e=emb(f"📊 {interaction.guild.name} 통계")
        e.add_field(name="멤버",value=str(interaction.guild.member_count))
        e.add_field(name="경고",value=str(warnings))
        e.add_field(name="티켓",value=str(tickets))
        e.add_field(name="신고/이의제기",value=str(reports))
        e.add_field(name="총 포인트",value=f"{points:,}")
        await interaction.response.send_message(embed=e,ephemeral=True)

async def setup(bot): await bot.add_cog(StatsCog(bot))
