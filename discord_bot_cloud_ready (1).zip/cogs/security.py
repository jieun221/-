import re,time
from collections import defaultdict,deque
from datetime import timedelta
import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.config import OWNER_ID
from core.utils import emb

BAD_LINK_PATTERNS = [
    r"discord(?:app)?\.gift",
    r"bit\.ly/",
    r"tinyurl\.com/",
]

class SecurityCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.msg_times=defaultdict(lambda:deque(maxlen=10))
        self.join_times=defaultdict(lambda:deque(maxlen=30))
    security=app_commands.Group(name="보안",description="보안 시스템")

    async def sec_log(self,guild,title,text):
        row=await self.bot.db.get_guild(guild.id)
        cid=row[11] if row else None
        ch=guild.get_channel(cid) if cid else None
        if ch:
            try: await ch.send(embed=emb(title,text,discord.Color.orange()))
            except Exception: pass

    @security.command(name="긴급잠금")
    @guild_manager_only()
    async def lockdown(self,interaction:discord.Interaction,사유:str="긴급 보안"):
        await interaction.response.defer(ephemeral=True)
        changed=0
        for ch in interaction.guild.text_channels:
            try:
                ow=ch.overwrites_for(interaction.guild.default_role)
                ow.send_messages=False
                await ch.set_permissions(interaction.guild.default_role,overwrite=ow,reason=사유)
                changed+=1
            except Exception: pass
        await self.bot.db.update_setting(interaction.guild.id,"lockdown",True)
        await interaction.followup.send(f"🔒 긴급 잠금 완료: {changed}개 채널",ephemeral=True)

    @security.command(name="긴급잠금해제")
    @guild_manager_only()
    async def unlock(self,interaction:discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        changed=0
        for ch in interaction.guild.text_channels:
            try:
                ow=ch.overwrites_for(interaction.guild.default_role)
                ow.send_messages=None
                await ch.set_permissions(interaction.guild.default_role,overwrite=ow,reason="긴급 잠금 해제")
                changed+=1
            except Exception: pass
        await self.bot.db.update_setting(interaction.guild.id,"lockdown",False)
        await interaction.followup.send(f"🔓 잠금 해제: {changed}개 채널",ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self,message):
        if not message.guild or message.author.bot or message.author.id==OWNER_ID: return
        key=(message.guild.id,message.author.id)
        q=self.msg_times[key]; q.append(time.monotonic())

        if len(q)>=8 and q[-1]-q[0]<=6:
            await self.sec_log(message.guild,"🚨 도배 감지",f"{message.author.mention} | {message.channel.mention}")
            try: await message.author.timeout(timedelta(minutes=5),reason="자동 도배 감지")
            except Exception: pass
            q.clear()

        if len(message.mentions)>=8:
            await self.sec_log(message.guild,"🚨 대량 멘션 감지",f"{message.author.mention} | 멘션 {len(message.mentions)}명")
            try: await message.delete()
            except Exception: pass

        lower=message.content.lower()
        if any(re.search(p,lower) for p in BAD_LINK_PATTERNS):
            await self.sec_log(message.guild,"⚠️ 위험 링크 감지",f"{message.author.mention}\n`{message.content[:500]}`")

    @commands.Cog.listener()
    async def on_member_join(self,member):
        q=self.join_times[member.guild.id]; q.append(time.monotonic())
        if len(q)>=15 and q[-1]-q[0]<=20:
            await self.sec_log(member.guild,"🚨 대량 입장 감지",f"20초 내 {len(q)}명 입장")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self,ch):
        await self.sec_log(ch.guild,"⚠️ 채널 삭제 감지",f"{ch.name} (`{ch.id}`)")

    @commands.Cog.listener()
    async def on_guild_role_delete(self,role):
        await self.sec_log(role.guild,"⚠️ 역할 삭제 감지",f"{role.name} (`{role.id}`)")

async def setup(bot): await bot.add_cog(SecurityCog(bot))
