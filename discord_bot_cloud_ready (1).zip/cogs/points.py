import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.db import now_iso
from core.utils import emb

class PointsCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    point=app_commands.Group(name="포인트",description="포인트 시스템")
    rank=app_commands.Group(name="랭크",description="랭크 시스템")

    async def balance(self,gid,uid):
        row=await self.bot.db.fetchone("SELECT amount FROM points WHERE guild_id=? AND user_id=?",(gid,uid))
        return row[0] if row else 0

    async def apply_rank(self,member):
        amount=await self.balance(member.guild.id,member.id)
        rows=await self.bot.db.fetchall("SELECT name,min_points,role_id FROM ranks WHERE guild_id=? ORDER BY min_points DESC",(member.guild.id,))
        target=None
        for name,minp,rid in rows:
            if amount>=minp:
                target=(name,minp,rid); break
        rank_role_ids={r[2] for r in rows if r[2]}
        for role in list(member.roles):
            if role.id in rank_role_ids and (not target or role.id!=target[2]):
                try: await member.remove_roles(role,reason="랭크 자동 조정")
                except Exception: pass
        if target and target[2]:
            role=member.guild.get_role(target[2])
            if role and role not in member.roles:
                try: await member.add_roles(role,reason="랭크 자동 승급")
                except Exception: pass

    async def change(self,gid,uid,actor,delta,reason):
        await self.bot.db.execute(
            "INSERT INTO points(guild_id,user_id,amount) VALUES(?,?,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET amount=amount+excluded.amount",
            (gid,uid,delta)
        )
        await self.bot.db.execute("INSERT INTO point_logs(guild_id,user_id,actor_id,delta,reason,created_at) VALUES(?,?,?,?,?,?)",(gid,uid,actor,delta,reason,now_iso()))

    @point.command(name="조회")
    async def get(self,interaction:discord.Interaction,멤버:discord.Member|None=None):
        m=멤버 or interaction.user
        amount=await self.balance(interaction.guild.id,m.id)
        s=await self.bot.db.get_settings(interaction.guild.id)
        name=s.get("point_name","포인트")
        await interaction.response.send_message(f"💰 {m.mention} — **{amount:,} {name}**")

    @point.command(name="지급")
    @guild_manager_only()
    async def add(self,interaction:discord.Interaction,멤버:discord.Member,수량:int,사유:str="관리진 지급"):
        await self.change(interaction.guild.id,멤버.id,interaction.user.id,abs(수량),사유)
        await self.apply_rank(멤버)
        await interaction.response.send_message(f"✅ {멤버.mention} +{abs(수량):,}")

    @point.command(name="차감")
    @guild_manager_only()
    async def sub(self,interaction:discord.Interaction,멤버:discord.Member,수량:int,사유:str="관리진 차감"):
        await self.change(interaction.guild.id,멤버.id,interaction.user.id,-abs(수량),사유)
        await self.apply_rank(멤버)
        await interaction.response.send_message(f"✅ {멤버.mention} -{abs(수량):,}")

    @point.command(name="순위")
    async def leaderboard(self,interaction:discord.Interaction):
        rows=await self.bot.db.fetchall("SELECT user_id,amount FROM points WHERE guild_id=? ORDER BY amount DESC LIMIT 20",(interaction.guild.id,))
        text="\n".join(f"`{i}.` <@{uid}> — **{amt:,}**" for i,(uid,amt) in enumerate(rows,1)) or "데이터 없음"
        await interaction.response.send_message(embed=emb("🏆 포인트 순위",text))

    @rank.command(name="등록")
    @guild_manager_only()
    async def rank_add(self,interaction:discord.Interaction,이름:str,필요포인트:int,역할:discord.Role|None=None):
        await self.bot.db.execute(
            "INSERT INTO ranks(guild_id,name,min_points,role_id) VALUES(?,?,?,?) "
            "ON CONFLICT(guild_id,name) DO UPDATE SET min_points=excluded.min_points,role_id=excluded.role_id",
            (interaction.guild.id,이름,필요포인트,역할.id if 역할 else None)
        )
        await interaction.response.send_message("✅ 랭크 등록",ephemeral=True)

    @rank.command(name="목록")
    async def rank_list(self,interaction:discord.Interaction):
        rows=await self.bot.db.fetchall("SELECT name,min_points,role_id FROM ranks WHERE guild_id=? ORDER BY min_points",(interaction.guild.id,))
        text="\n".join(f"• **{n}** {p:,}P {f'<@&{r}>' if r else ''}" for n,p,r in rows) or "없음"
        await interaction.response.send_message(embed=emb("🏷️ 랭크",text))

async def setup(bot): await bot.add_cog(PointsCog(bot))
