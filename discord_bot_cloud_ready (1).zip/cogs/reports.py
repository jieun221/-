import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.db import now_iso
from core.utils import emb

class ReportsCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    report=app_commands.Group(name="신고",description="신고/이의제기")

    @report.command(name="접수")
    async def create(self,interaction:discord.Interaction,대상:discord.Member,내용:str):
        rid=await self.bot.db.execute(
            "INSERT INTO reports(guild_id,reporter_id,target_id,type,content,status,created_at) VALUES(?,?,?,?,?,?,?)",
            (interaction.guild.id,interaction.user.id,대상.id,"신고",내용,"접수",now_iso())
        )
        row=await self.bot.db.get_guild(interaction.guild.id)
        ch=interaction.guild.get_channel(row[10]) if row and row[10] else None
        if ch:
            await ch.send(embed=emb(f"📝 신고 #{rid}",f"신고자: {interaction.user.mention}\n대상: {대상.mention}\n내용: {내용}"))
        await interaction.response.send_message(f"✅ 신고 #{rid} 접수",ephemeral=True)

    @report.command(name="이의제기")
    async def appeal(self,interaction:discord.Interaction,내용:str):
        rid=await self.bot.db.execute(
            "INSERT INTO reports(guild_id,reporter_id,target_id,type,content,status,created_at) VALUES(?,?,?,?,?,?,?)",
            (interaction.guild.id,interaction.user.id,interaction.user.id,"이의제기",내용,"접수",now_iso())
        )
        await interaction.response.send_message(f"✅ 이의제기 #{rid} 접수",ephemeral=True)

    @report.command(name="처리")
    @guild_manager_only()
    async def process(self,interaction:discord.Interaction,신고_id:int,상태:str,결과:str):
        await self.bot.db.execute("UPDATE reports SET status=?,staff_id=?,result=? WHERE id=? AND guild_id=?",(상태,interaction.user.id,결과,신고_id,interaction.guild.id))
        await interaction.response.send_message(f"✅ #{신고_id} → {상태}",ephemeral=True)

async def setup(bot): await bot.add_cog(ReportsCog(bot))
