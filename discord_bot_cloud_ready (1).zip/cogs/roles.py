import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only

class RolesCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    role=app_commands.Group(name="역할",description="역할 관리")

    @role.command(name="지급")
    @guild_manager_only()
    async def give(self,interaction:discord.Interaction,멤버:discord.Member,역할:discord.Role):
        await 멤버.add_roles(역할,reason=f"{interaction.user} 명령")
        await self.bot.db.audit(interaction.guild.id,interaction.user.id,"ROLE_GIVE",target_id=멤버.id,after={"role_id":역할.id})
        await interaction.response.send_message(f"✅ {멤버.mention} → {역할.mention}")

    @role.command(name="회수")
    @guild_manager_only()
    async def remove(self,interaction:discord.Interaction,멤버:discord.Member,역할:discord.Role):
        await 멤버.remove_roles(역할,reason=f"{interaction.user} 명령")
        await self.bot.db.audit(interaction.guild.id,interaction.user.id,"ROLE_REMOVE",target_id=멤버.id,after={"role_id":역할.id})
        await interaction.response.send_message(f"✅ {멤버.mention} ← {역할.mention}")

    @commands.Cog.listener()
    async def on_member_join(self,member):
        s=await self.bot.db.get_settings(member.guild.id)
        rid=s.get("auto_role_id")
        role=member.guild.get_role(rid) if rid else None
        if role:
            try: await member.add_roles(role,reason="자동 입장 역할")
            except Exception: pass

async def setup(bot): await bot.add_cog(RolesCog(bot))
