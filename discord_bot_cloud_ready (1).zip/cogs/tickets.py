import discord
from discord import app_commands
from discord.ext import commands
from core.db import now_iso
from core.utils import emb

class TicketCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    ticket=app_commands.Group(name="티켓",description="티켓 시스템")

    @ticket.command(name="생성")
    async def create(self,interaction:discord.Interaction,종류:str="문의"):
        guild=interaction.guild
        row=await self.bot.db.get_guild(guild.id)
        category=guild.get_channel(row[7]) if row and row[7] else None
        overwrites={
            guild.default_role:discord.PermissionOverwrite(view_channel=False),
            interaction.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True),
            guild.me:discord.PermissionOverwrite(view_channel=True,send_messages=True,manage_channels=True)
        }
        ch=await guild.create_text_channel(
            f"ticket-{interaction.user.name}"[:90],
            category=category if isinstance(category,discord.CategoryChannel) else None,
            overwrites=overwrites,
            reason=f"{종류} 티켓"
        )
        tid=await self.bot.db.execute(
            "INSERT INTO tickets(guild_id,channel_id,opener_id,type,status,created_at) VALUES(?,?,?,?,?,?)",
            (guild.id,ch.id,interaction.user.id,종류,"open",now_iso())
        )
        await ch.send(interaction.user.mention,embed=emb(f"🎫 {종류} 티켓",f"티켓 ID: `{tid}`\n내용을 작성해주세요.\n닫기: `/티켓 닫기`"))
        await interaction.response.send_message(f"✅ {ch.mention} 생성",ephemeral=True)

    @ticket.command(name="담당")
    async def assign(self,interaction:discord.Interaction,담당자:discord.Member|None=None):
        row=await self.bot.db.fetchone("SELECT id FROM tickets WHERE channel_id=? AND status='open'",(interaction.channel.id,))
        if not row: return await interaction.response.send_message("티켓 채널이 아닙니다.",ephemeral=True)
        staff=담당자 or interaction.user
        await self.bot.db.execute("UPDATE tickets SET staff_id=? WHERE id=?",(staff.id,row[0]))
        await interaction.response.send_message(f"👤 담당자: {staff.mention}")

    @ticket.command(name="닫기")
    async def close(self,interaction:discord.Interaction):
        row=await self.bot.db.fetchone("SELECT id FROM tickets WHERE channel_id=? AND status='open'",(interaction.channel.id,))
        if not row: return await interaction.response.send_message("열린 티켓이 아닙니다.",ephemeral=True)
        await self.bot.db.execute("UPDATE tickets SET status='closed',closed_at=? WHERE id=?",(now_iso(),row[0]))
        await interaction.response.send_message("🔒 티켓을 닫았습니다. 5초 후 채널을 삭제합니다.")
        import asyncio
        await asyncio.sleep(5)
        try: await interaction.channel.delete(reason="티켓 종료")
        except Exception: pass

async def setup(bot): await bot.add_cog(TicketCog(bot))
