import json
import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.utils import emb

class SettingsCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    setting=app_commands.Group(name="설정",description="서버별 설정")
    rep=app_commands.Group(name="대표",description="대표 관리")

    @setting.command(name="보기")
    @guild_manager_only()
    async def view(self,interaction:discord.Interaction):
        row=await self.bot.db.get_guild(interaction.guild.id)
        s=await self.bot.db.get_settings(interaction.guild.id)
        e=emb(f"⚙️ {interaction.guild.name} 설정")
        names=[
            ("공지채널",4),("로그채널",5),("티켓생성채널",6),("티켓카테고리",7),
            ("출퇴근채널",8),("이벤트채널",9),("신고로그",10),("보안로그",11)
        ]
        for title,idx in names:
            obj=interaction.guild.get_channel(row[idx]) if row and row[idx] else None
            e.add_field(name=title,value=obj.mention if obj and hasattr(obj,"mention") else "미설정")
        e.add_field(name="기타 설정",value=f"```json\n{json.dumps(s,ensure_ascii=False,indent=2)[:900]}\n```",inline=False)
        await interaction.response.send_message(embed=e,ephemeral=True)

    async def _set(self,interaction,field,channel):
        await self.bot.db.set_guild_field(interaction.guild.id,field,channel.id)
        await self.bot.db.audit(interaction.guild.id,interaction.user.id,"SETTING_CHANNEL",target_id=channel.id,after={"field":field})
        await interaction.response.send_message(f"✅ {channel.mention} 설정 완료",ephemeral=True)

    @setting.command(name="공지채널")
    @guild_manager_only()
    async def ann(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"announcement_channel_id",채널)

    @setting.command(name="로그채널")
    @guild_manager_only()
    async def log(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"log_channel_id",채널)

    @setting.command(name="티켓생성채널")
    @guild_manager_only()
    async def ticket_ch(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"ticket_channel_id",채널)

    @setting.command(name="티켓카테고리")
    @guild_manager_only()
    async def ticket_cat(self,interaction:discord.Interaction,카테고리:discord.CategoryChannel): await self._set(interaction,"ticket_category_id",카테고리)

    @setting.command(name="출퇴근채널")
    @guild_manager_only()
    async def clock_ch(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"staff_clock_channel_id",채널)

    @setting.command(name="이벤트채널")
    @guild_manager_only()
    async def event_ch(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"event_channel_id",채널)

    @setting.command(name="신고로그채널")
    @guild_manager_only()
    async def report_ch(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"report_log_channel_id",채널)

    @setting.command(name="보안로그채널")
    @guild_manager_only()
    async def sec_ch(self,interaction:discord.Interaction,채널:discord.TextChannel): await self._set(interaction,"security_log_channel_id",채널)

    @setting.command(name="자동역할")
    @guild_manager_only()
    async def autorole(self,interaction:discord.Interaction,역할:discord.Role|None=None):
        await self.bot.db.update_setting(interaction.guild.id,"auto_role_id",역할.id if 역할 else None)
        await interaction.response.send_message(f"✅ 자동 역할: {역할.mention if 역할 else '해제'}",ephemeral=True)

    @setting.command(name="포인트이름")
    @guild_manager_only()
    async def point_name(self,interaction:discord.Interaction,이름:str):
        await self.bot.db.update_setting(interaction.guild.id,"point_name",이름)
        await interaction.response.send_message(f"✅ 포인트 이름: {이름}",ephemeral=True)

    @rep.command(name="추가")
    @guild_manager_only()
    async def rep_add(self,interaction:discord.Interaction,멤버:discord.Member):
        await self.bot.db.add_rep(interaction.guild.id,멤버.id,interaction.user.id)
        await interaction.response.send_message(f"👑 {멤버.mention} 대표 등록",ephemeral=True)

    @rep.command(name="삭제")
    @guild_manager_only()
    async def rep_del(self,interaction:discord.Interaction,멤버:discord.Member):
        await self.bot.db.remove_rep(interaction.guild.id,멤버.id)
        await interaction.response.send_message(f"✅ {멤버.mention} 대표 해제",ephemeral=True)

    @rep.command(name="목록")
    async def rep_list(self,interaction:discord.Interaction):
        rows=await self.bot.db.list_reps(interaction.guild.id)
        await interaction.response.send_message(embed=emb("👑 대표 목록","\n".join(f"• <@{r[0]}>" for r in rows) or "없음"),ephemeral=True)

async def setup(bot): await bot.add_cog(SettingsCog(bot))
