from datetime import timedelta
import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.config import OWNER_ID
from core.db import now_iso

class ModerationCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    mod=app_commands.Group(name="제재",description="제재 시스템")

    def protected(self,m):
        return m.id in {OWNER_ID,self.bot.user.id}

    @mod.command(name="경고")
    @guild_manager_only()
    async def warn(self,interaction:discord.Interaction,멤버:discord.Member,사유:str):
        if self.protected(멤버): return await interaction.response.send_message("⛔ 보호 대상",ephemeral=True)
        await self.bot.db.execute("INSERT INTO warnings(guild_id,user_id,moderator_id,reason,created_at) VALUES(?,?,?,?,?)",(interaction.guild.id,멤버.id,interaction.user.id,사유,now_iso()))
        count=(await self.bot.db.fetchone("SELECT COUNT(*) FROM warnings WHERE guild_id=? AND user_id=?",(interaction.guild.id,멤버.id)))[0]
        await interaction.response.send_message(f"⚠️ {멤버.mention} 경고 {count}회\n사유: {사유}")

    @mod.command(name="경고해제")
    @guild_manager_only()
    async def clear(self,interaction:discord.Interaction,멤버:discord.Member):
        await self.bot.db.execute("DELETE FROM warnings WHERE guild_id=? AND user_id=?",(interaction.guild.id,멤버.id))
        await interaction.response.send_message("✅ 경고 전체 해제")

    @mod.command(name="타임아웃")
    @guild_manager_only()
    async def timeout(self,interaction:discord.Interaction,멤버:discord.Member,분:app_commands.Range[int,1,40320],사유:str):
        if self.protected(멤버): return await interaction.response.send_message("⛔ 보호 대상",ephemeral=True)
        await 멤버.timeout(timedelta(minutes=분),reason=사유)
        await interaction.response.send_message(f"⏱️ {멤버.mention} {분}분 타임아웃")

    @mod.command(name="타임아웃해제")
    @guild_manager_only()
    async def timeout_off(self,interaction:discord.Interaction,멤버:discord.Member):
        await 멤버.timeout(None)
        await interaction.response.send_message("✅ 타임아웃 해제")

    @mod.command(name="추방")
    @guild_manager_only()
    async def kick(self,interaction:discord.Interaction,멤버:discord.Member,사유:str):
        if self.protected(멤버): return await interaction.response.send_message("⛔ 보호 대상",ephemeral=True)
        await 멤버.kick(reason=사유)
        await interaction.response.send_message("👢 추방 완료")

    @mod.command(name="차단")
    @guild_manager_only()
    async def ban(self,interaction:discord.Interaction,멤버:discord.Member,사유:str):
        if self.protected(멤버): return await interaction.response.send_message("⛔ 보호 대상",ephemeral=True)
        await interaction.guild.ban(멤버,reason=사유)
        await interaction.response.send_message("🔨 차단 완료")

    @mod.command(name="차단해제")
    @guild_manager_only()
    async def unban(self,interaction:discord.Interaction,사용자_id:str):
        user=await self.bot.fetch_user(int(사용자_id))
        await interaction.guild.unban(user)
        await interaction.response.send_message("✅ 차단 해제")

async def setup(bot): await bot.add_cog(ModerationCog(bot))
