import random
import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.db import now_iso
from core.utils import emb

class EventsCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    event=app_commands.Group(name="이벤트",description="이벤트 시스템")

    @event.command(name="생성")
    @guild_manager_only()
    async def create(self,interaction:discord.Interaction,제목:str,설명:str,당첨자수:app_commands.Range[int,1,20]=1):
        row=await self.bot.db.get_guild(interaction.guild.id)
        ch=interaction.guild.get_channel(row[9]) if row and row[9] else interaction.channel
        eid=await self.bot.db.execute(
            "INSERT INTO events(guild_id,title,description,winners,channel_id,active,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (interaction.guild.id,제목,설명,당첨자수,ch.id,1,interaction.user.id,now_iso())
        )
        msg=await ch.send(embed=emb(f"🎁 {제목}",f"{설명}\n\n참여: `/이벤트 참여 {eid}`\n당첨자: {당첨자수}명"))
        await self.bot.db.execute("UPDATE events SET message_id=? WHERE id=?",(msg.id,eid))
        await interaction.response.send_message(f"✅ 이벤트 ID `{eid}` 생성",ephemeral=True)

    @event.command(name="참여")
    async def join(self,interaction:discord.Interaction,이벤트_id:int):
        row=await self.bot.db.fetchone("SELECT active FROM events WHERE id=? AND guild_id=?",(이벤트_id,interaction.guild.id))
        if not row or not row[0]: return await interaction.response.send_message("진행 중인 이벤트가 아닙니다.",ephemeral=True)
        await self.bot.db.execute("INSERT OR IGNORE INTO event_entries(event_id,user_id) VALUES(?,?)",(이벤트_id,interaction.user.id))
        await interaction.response.send_message("🎉 참여 완료",ephemeral=True)

    @event.command(name="종료")
    @guild_manager_only()
    async def end(self,interaction:discord.Interaction,이벤트_id:int):
        row=await self.bot.db.fetchone("SELECT title,winners FROM events WHERE id=? AND guild_id=? AND active=1",(이벤트_id,interaction.guild.id))
        if not row: return await interaction.response.send_message("이벤트 없음",ephemeral=True)
        entries=await self.bot.db.fetchall("SELECT user_id FROM event_entries WHERE event_id=?",(이벤트_id,))
        if not entries: return await interaction.response.send_message("참여자가 없습니다.",ephemeral=True)
        winners=random.sample([r[0] for r in entries],min(row[1],len(entries)))
        await self.bot.db.execute("UPDATE events SET active=0 WHERE id=?",(이벤트_id,))
        await interaction.response.send_message(embed=emb(f"🏆 {row[0]} 당첨자","\n".join(f"<@{u}>" for u in winners)))

async def setup(bot): await bot.add_cog(EventsCog(bot))
