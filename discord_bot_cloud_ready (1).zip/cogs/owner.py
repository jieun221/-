import asyncio
from datetime import datetime, timezone
import discord, psutil
from discord import app_commands
from discord.ext import commands
from core.checks import owner_only
from core.config import OWNER_ID, OWNER_NAME
from core.utils import emb

class OwnerCog(commands.Cog):
    def __init__(self, bot): self.bot=bot
    total=app_commands.Group(name="총괄",description="onexuh 전용 전체 관리")

    @total.command(name="상태")
    @owner_only()
    async def status(self, interaction:discord.Interaction):
        p=psutil.Process()
        state=await self.bot.db.get_global("maintenance",{"enabled":False})
        e=emb("🩺 봇 전체 상태")
        e.add_field(name="소유자",value=f"{OWNER_NAME}\n`{OWNER_ID}`")
        e.add_field(name="서버",value=str(len(self.bot.guilds)))
        e.add_field(name="메모리",value=f"{p.memory_info().rss/1024/1024:.1f} MB")
        e.add_field(name="점검",value="ON" if state.get("enabled") else "OFF")
        await interaction.response.send_message(embed=e,ephemeral=True)

    @total.command(name="점검")
    @owner_only()
    async def maintenance(self,interaction:discord.Interaction,사유:str,종료예정:str="미정",오류내용:str="없음",예상복구:str="미정",추가안내:str="-"):
        state={"enabled":True,"reason":사유,"eta":종료예정,"error":오류내용,"recovery":예상복구,"notice":추가안내,"started_at":datetime.now(timezone.utc).isoformat()}
        await self.bot.db.set_global("maintenance",state)
        await self.bot.db.audit(None,interaction.user.id,"MAINTENANCE_ON",reason=사유,after=state)
        await interaction.response.send_message("🛠️ 전체 점검 시작",ephemeral=True)

    @total.command(name="점검해제")
    @owner_only()
    async def maintenance_off(self,interaction:discord.Interaction):
        before=await self.bot.db.get_global("maintenance",{"enabled":False})
        await self.bot.db.set_global("maintenance",{"enabled":False})
        await self.bot.db.audit(None,interaction.user.id,"MAINTENANCE_OFF",before=before)
        await interaction.response.send_message("✅ 점검 해제",ephemeral=True)

    @total.command(name="서버목록")
    @owner_only()
    async def guilds(self,interaction:discord.Interaction):
        rows=await self.bot.db.list_guilds()
        lines=[]
        for row in rows[:80]:
            gid,name,joined,blocked,*rest=row
            g=self.bot.get_guild(gid)
            lines.append(f"{'🔴' if blocked else '🟢'} **{name}** | `{gid}` | {g.member_count if g else '?'}명")
        await interaction.response.send_message(embed=emb("📊 서버 목록","\n".join(lines) or "없음"),ephemeral=True)

    @total.command(name="서버차단")
    @owner_only()
    async def block(self,interaction:discord.Interaction,서버_id:str,사유:str="소유자 조치"):
        gid=int(서버_id)
        await self.bot.db.set_guild_field(gid,"blocked",1)
        await self.bot.db.audit(gid,interaction.user.id,"GUILD_BLOCK",target_id=gid,reason=사유)
        await interaction.response.send_message(f"⛔ `{gid}` 서버 차단",ephemeral=True)

    @total.command(name="서버차단해제")
    @owner_only()
    async def unblock(self,interaction:discord.Interaction,서버_id:str):
        gid=int(서버_id)
        await self.bot.db.set_guild_field(gid,"blocked",0)
        await self.bot.db.audit(gid,interaction.user.id,"GUILD_UNBLOCK",target_id=gid)
        await interaction.response.send_message(f"✅ `{gid}` 서버 차단 해제",ephemeral=True)

    @total.command(name="공지")
    @owner_only()
    async def notice(self,interaction:discord.Interaction,제목:str,내용:str):
        await interaction.response.defer(ephemeral=True)
        ok=fail=0
        for guild in self.bot.guilds:
            row=await self.bot.db.get_guild(guild.id)
            channel=guild.get_channel(row[4]) if row and row[4] else None
            if channel:
                try:
                    await channel.send(embed=emb(f"📢 {제목}",내용))
                    ok+=1
                except Exception: fail+=1
            else: fail+=1
            await asyncio.sleep(.25)
        await self.bot.db.audit(None,interaction.user.id,"GLOBAL_NOTICE",reason=제목,after={"success":ok,"fail":fail})
        await interaction.followup.send(f"성공 {ok} / 실패 {fail}",ephemeral=True)

async def setup(bot): await bot.add_cog(OwnerCog(bot))
