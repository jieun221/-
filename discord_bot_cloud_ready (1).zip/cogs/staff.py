import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.db import now_iso
from core.utils import emb

class StaffCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    staff=app_commands.Group(name="관리진",description="관리진 시스템")
    clock=app_commands.Group(name="출퇴근",description="관리진 출퇴근")

    @staff.command(name="직책등록")
    @guild_manager_only()
    async def register(self,interaction:discord.Interaction,직책명:str,역할:discord.Role,레벨:app_commands.Range[int,1,100]=1):
        await self.bot.db.execute(
            "INSERT INTO staff_roles(guild_id,title,role_id,level,created_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(guild_id,title) DO UPDATE SET role_id=excluded.role_id,level=excluded.level",
            (interaction.guild.id,직책명,역할.id,레벨,now_iso())
        )
        await interaction.response.send_message(f"✅ {직책명} → {역할.mention}",ephemeral=True)

    @staff.command(name="직책삭제")
    @guild_manager_only()
    async def delete(self,interaction:discord.Interaction,직책명:str):
        await self.bot.db.execute("DELETE FROM staff_roles WHERE guild_id=? AND title=?",(interaction.guild.id,직책명))
        await interaction.response.send_message("✅ 직책 삭제",ephemeral=True)

    @staff.command(name="직책목록")
    async def list_roles(self,interaction:discord.Interaction):
        rows=await self.bot.db.fetchall("SELECT title,role_id,level FROM staff_roles WHERE guild_id=? ORDER BY level DESC",(interaction.guild.id,))
        text="\n".join(f"• **{t}** | <@&{rid}> | Lv.{lv}" for t,rid,lv in rows) or "등록 없음"
        await interaction.response.send_message(embed=emb("👑 관리진 직책",text),ephemeral=True)

    @clock.command(name="출근")
    async def clockin(self,interaction:discord.Interaction):
        active=await self.bot.db.fetchone("SELECT id FROM staff_clock WHERE guild_id=? AND user_id=? AND clock_out IS NULL",(interaction.guild.id,interaction.user.id))
        if active:
            return await interaction.response.send_message("이미 출근 상태입니다.",ephemeral=True)
        await self.bot.db.execute("INSERT INTO staff_clock(guild_id,user_id,clock_in) VALUES(?,?,?)",(interaction.guild.id,interaction.user.id,now_iso()))
        await interaction.response.send_message(f"🟢 {interaction.user.mention} 출근 기록 완료")

    @clock.command(name="퇴근")
    async def clockout(self,interaction:discord.Interaction):
        row=await self.bot.db.fetchone("SELECT id,clock_in FROM staff_clock WHERE guild_id=? AND user_id=? AND clock_out IS NULL ORDER BY id DESC",(interaction.guild.id,interaction.user.id))
        if not row:
            return await interaction.response.send_message("출근 기록이 없습니다.",ephemeral=True)
        await self.bot.db.execute("UPDATE staff_clock SET clock_out=? WHERE id=?",(now_iso(),row[0]))
        await interaction.response.send_message(f"🔴 {interaction.user.mention} 퇴근 기록 완료")

    @clock.command(name="기록")
    @guild_manager_only()
    async def history(self,interaction:discord.Interaction,멤버:discord.Member):
        rows=await self.bot.db.fetchall("SELECT clock_in,clock_out FROM staff_clock WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10",(interaction.guild.id,멤버.id))
        text="\n".join(f"• {a} → {b or '근무중'}" for a,b in rows) or "기록 없음"
        await interaction.response.send_message(embed=emb(f"⏰ {멤버} 출퇴근 기록",text),ephemeral=True)

async def setup(bot): await bot.add_cog(StaffCog(bot))
