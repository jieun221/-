import json
from pathlib import Path
import discord
from discord import app_commands
from discord.ext import commands
from core.checks import guild_manager_only
from core.utils import emb

class BackupCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    backup=app_commands.Group(name="백업",description="백업/복구")

    @backup.command(name="생성")
    @guild_manager_only()
    async def create(self,interaction:discord.Interaction):
        guild=interaction.guild
        data={
            "guild":{"id":guild.id,"name":guild.name},
            "roles":[{"id":r.id,"name":r.name,"permissions":r.permissions.value,"color":r.color.value,"hoist":r.hoist,"mentionable":r.mentionable} for r in guild.roles if not r.is_default()],
            "channels":[
                {"id":c.id,"name":c.name,"type":str(c.type),"position":c.position,"category_id":getattr(c,"category_id",None)}
                for c in guild.channels
            ],
            "settings":await self.bot.db.get_settings(guild.id),
            "points":[{"user_id":u,"amount":a} for u,a in await self.bot.db.fetchall("SELECT user_id,amount FROM points WHERE guild_id=?",(guild.id,))],
            "ranks":[{"name":n,"min_points":p,"role_id":r} for n,p,r in await self.bot.db.fetchall("SELECT name,min_points,role_id FROM ranks WHERE guild_id=?",(guild.id,))]
        }
        path=Path("backups")/f"{guild.id}.json"
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        await interaction.response.send_message(file=discord.File(path),content="💾 백업 생성 완료",ephemeral=True)

    @backup.command(name="설정복구")
    @guild_manager_only()
    async def restore_settings(self,interaction:discord.Interaction):
        path=Path("backups")/f"{interaction.guild.id}.json"
        if not path.exists(): return await interaction.response.send_message("백업 파일이 없습니다.",ephemeral=True)
        data=json.loads(path.read_text(encoding="utf-8"))
        for k,v in data.get("settings",{}).items():
            await self.bot.db.update_setting(interaction.guild.id,k,v)
        await interaction.response.send_message("✅ 서버 설정 복구 완료",ephemeral=True)

async def setup(bot): await bot.add_cog(BackupCog(bot))
