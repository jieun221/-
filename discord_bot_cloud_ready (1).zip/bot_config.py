import os

BOT_TOKEN = os.getenv("DISCORD_TOKEN", "")

CLIENT_ID = 1539951135236947969
OWNER_ID = 1227908466480386080
OWNER_NAME = "onexuh"
DATABASE_PATH = os.getenv("DATABASE_PATH", "data/bot.db")

if not BOT_TOKEN:
    raise RuntimeError(
        "DISCORD_TOKEN 환경변수가 없습니다. "
        "호스팅 사이트의 Secrets/Environment Variables에 DISCORD_TOKEN을 등록하세요."
    )
