# Discord 총관리 봇 FULL

소유자: `onexuh`
OWNER_ID: `1227908466480386080`

## 핵심 기능
- 소유자 전용 `/총괄`
- 전체 점검 / 점검해제
- 전체 공지
- 서버 차단 / 해제
- 전체 서버 통계
- 서버 대표 관리
- 서버별 설정
- 관리진 직책
- 관리진 출퇴근
- 역할 지급 / 회수
- 자동 역할
- 포인트 / 랭크
- 티켓
- 신고 / 이의제기
- 경고 / 타임아웃 / 추방 / 차단
- 스팸 / 대량 멘션 / 위험 링크 기본 감지
- 안티레이드 기본 감지
- 긴급 서버 잠금 / 해제
- 이벤트 / 추첨
- 로그 시스템
- 서버 설정 / 역할 / 채널 / 포인트 백업
- 복구용 백업 파일 생성
- 서버 통계
- 감사 로그 DB 저장
- 오류 및 상태 확인

## 실행
1. Python 3.11+ 설치
2. `pip install -r requirements.txt`
3. `.env`의 `DISCORD_TOKEN`에 봇 토큰 입력
4. Discord Developer Portal > Bot > Privileged Gateway Intents:
   - SERVER MEMBERS INTENT ON
   - MESSAGE CONTENT INTENT ON
5. 봇에 필요한 권한 부여
6. `python main.py`

## 주의
Discord API 자체 제한 때문에 서버를 완전히 원상복구하는 기능은 역할/채널 권한 및 순서에 따라 일부 수동 조정이 필요할 수 있습니다.
