import discord
from discord import app_commands
from .config import OWNER_ID

def owner_only():
    async def pred(interaction: discord.Interaction):
        if interaction.user.id != OWNER_ID:
            raise app_commands.CheckFailure("onexuh 소유자 전용 명령어입니다.")
        return True
    return app_commands.check(pred)

def guild_manager_only():
    async def pred(interaction: discord.Interaction):
        if interaction.user.id == OWNER_ID:
            return True
        if not interaction.guild:
            raise app_commands.CheckFailure("서버에서만 사용할 수 있습니다.")
        if interaction.user.guild_permissions.administrator:
            return True
        if await interaction.client.db.is_rep(interaction.guild.id, interaction.user.id):
            return True
        staff = await interaction.client.db.fetchone(
            "SELECT 1 FROM staff_roles s JOIN member_roles_dummy m ON 1=0"
        ) if False else None
        raise app_commands.CheckFailure("대표 또는 관리자 권한이 필요합니다.")
    return app_commands.check(pred)
