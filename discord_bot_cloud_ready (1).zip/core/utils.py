import discord
from datetime import datetime, timezone

def emb(title, desc="", color=None):
    return discord.Embed(
        title=title,
        description=desc,
        color=color or discord.Color.blurple(),
        timestamp=datetime.now(timezone.utc)
    )

async def send_log(bot, guild, title, description, field_index=5):
    row = await bot.db.get_guild(guild.id)
    if not row:
        return
    channel_id = row[field_index]
    channel = guild.get_channel(channel_id) if channel_id else None
    if channel:
        try:
            await channel.send(embed=emb(title,description))
        except Exception:
            pass
