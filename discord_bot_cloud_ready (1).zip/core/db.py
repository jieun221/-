import json
from datetime import datetime, timezone
import aiosqlite

def now_iso():
    return datetime.now(timezone.utc).isoformat()

SCHEMA = """
CREATE TABLE IF NOT EXISTS global_state(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guilds(
  guild_id INTEGER PRIMARY KEY,
  guild_name TEXT,
  joined_at TEXT,
  blocked INTEGER NOT NULL DEFAULT 0,
  announcement_channel_id INTEGER,
  log_channel_id INTEGER,
  ticket_channel_id INTEGER,
  ticket_category_id INTEGER,
  staff_clock_channel_id INTEGER,
  event_channel_id INTEGER,
  report_log_channel_id INTEGER,
  security_log_channel_id INTEGER,
  settings_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS representatives(
  guild_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  added_by INTEGER,
  created_at TEXT NOT NULL,
  PRIMARY KEY(guild_id,user_id)
);

CREATE TABLE IF NOT EXISTS staff_roles(
  guild_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  role_id INTEGER NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  PRIMARY KEY(guild_id,title)
);

CREATE TABLE IF NOT EXISTS staff_clock(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  clock_in TEXT NOT NULL,
  clock_out TEXT
);

CREATE TABLE IF NOT EXISTS points(
  guild_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  amount INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(guild_id,user_id)
);

CREATE TABLE IF NOT EXISTS point_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  actor_id INTEGER NOT NULL,
  delta INTEGER NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ranks(
  guild_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  min_points INTEGER NOT NULL,
  role_id INTEGER,
  PRIMARY KEY(guild_id,name)
);

CREATE TABLE IF NOT EXISTS warnings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  moderator_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  channel_id INTEGER NOT NULL UNIQUE,
  opener_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  staff_id INTEGER,
  created_at TEXT NOT NULL,
  closed_at TEXT
);

CREATE TABLE IF NOT EXISTS reports(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  reporter_id INTEGER NOT NULL,
  target_id INTEGER,
  type TEXT NOT NULL,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT '접수',
  staff_id INTEGER,
  result TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  winners INTEGER NOT NULL DEFAULT 1,
  channel_id INTEGER,
  message_id INTEGER,
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_entries(
  event_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  PRIMARY KEY(event_id,user_id)
);

CREATE TABLE IF NOT EXISTS audit_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER,
  actor_id INTEGER,
  action TEXT NOT NULL,
  target_id TEXT,
  reason TEXT,
  before_json TEXT,
  after_json TEXT,
  created_at TEXT NOT NULL
);
"""

class Database:
    def __init__(self, path):
        self.path = path

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(SCHEMA)
            await db.commit()

    async def execute(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(sql, params)
            await db.commit()
            return cur.lastrowid

    async def fetchone(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(sql, params)
            return await cur.fetchone()

    async def fetchall(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(sql, params)
            return await cur.fetchall()

    async def set_global(self, key, value):
        await self.execute(
            "INSERT INTO global_state(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False))
        )

    async def get_global(self, key, default=None):
        row = await self.fetchone("SELECT value FROM global_state WHERE key=?", (key,))
        return default if row is None else json.loads(row[0])

    async def upsert_guild(self, guild_id, guild_name, joined_at=None):
        await self.execute(
            "INSERT INTO guilds(guild_id,guild_name,joined_at) VALUES(?,?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET guild_name=excluded.guild_name",
            (guild_id,guild_name,joined_at or now_iso())
        )

    async def get_guild(self, guild_id):
        return await self.fetchone("SELECT * FROM guilds WHERE guild_id=?", (guild_id,))

    async def list_guilds(self):
        return await self.fetchall("SELECT * FROM guilds ORDER BY guild_name")

    async def set_guild_field(self, guild_id, field, value):
        allowed = {
            "blocked","announcement_channel_id","log_channel_id","ticket_channel_id",
            "ticket_category_id","staff_clock_channel_id","event_channel_id",
            "report_log_channel_id","security_log_channel_id","settings_json"
        }
        if field not in allowed:
            raise ValueError("허용되지 않은 필드")
        await self.execute(f"UPDATE guilds SET {field}=? WHERE guild_id=?", (value,guild_id))

    async def is_guild_blocked(self, guild_id):
        row = await self.fetchone("SELECT blocked FROM guilds WHERE guild_id=?", (guild_id,))
        return bool(row and row[0])

    async def get_settings(self, guild_id):
        row = await self.fetchone("SELECT settings_json FROM guilds WHERE guild_id=?", (guild_id,))
        try:
            return json.loads(row[0]) if row and row[0] else {}
        except Exception:
            return {}

    async def update_setting(self, guild_id, key, value):
        s = await self.get_settings(guild_id)
        s[key] = value
        await self.set_guild_field(guild_id, "settings_json", json.dumps(s, ensure_ascii=False))

    async def add_rep(self, guild_id, user_id, added_by):
        await self.execute(
            "INSERT OR IGNORE INTO representatives(guild_id,user_id,added_by,created_at) VALUES(?,?,?,?)",
            (guild_id,user_id,added_by,now_iso())
        )

    async def remove_rep(self, guild_id, user_id):
        await self.execute("DELETE FROM representatives WHERE guild_id=? AND user_id=?", (guild_id,user_id))

    async def is_rep(self, guild_id, user_id):
        return (await self.fetchone("SELECT 1 FROM representatives WHERE guild_id=? AND user_id=?", (guild_id,user_id))) is not None

    async def list_reps(self, guild_id):
        return await self.fetchall("SELECT user_id,added_by,created_at FROM representatives WHERE guild_id=?", (guild_id,))

    async def audit(self, guild_id, actor_id, action, target_id=None, reason=None, before=None, after=None):
        await self.execute(
            "INSERT INTO audit_logs(guild_id,actor_id,action,target_id,reason,before_json,after_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (
                guild_id,actor_id,action,str(target_id) if target_id is not None else None,reason,
                json.dumps(before,ensure_ascii=False) if before is not None else None,
                json.dumps(after,ensure_ascii=False) if after is not None else None,now_iso()
            )
        )
